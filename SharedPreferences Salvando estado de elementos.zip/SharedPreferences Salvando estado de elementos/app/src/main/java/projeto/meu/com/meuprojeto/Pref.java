package projeto.meu.com.meuprojeto;



/**
 * Created by DEF on 18/10/2016.
 * www.aksr.com.br
 */
import android.app.*;
import android.content.*;
import android.os.*;
import android.support.design.*;
import android.view.*;
import android.widget.*;
import projeto.meu.com.meuprojeto.*;

import android.support.design.R;

public class Pref extends Activity
 {
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pref);

        final Button u = (Button)findViewById(R.id.um);
        final Button d = (Button)findViewById(R.id.dois);
        final Button t = (Button)findViewById(R.id.tres);
        final Button q = (Button)findViewById(R.id.quatro);
        final TextView tv = (TextView)findViewById(R.id.getpref);


        SharedPreferences Botao = getSharedPreferences("Pref", MODE_PRIVATE);
        String botao = Botao.getString("btn", "");
        switch (botao) {
            case "1":
                u.setBackgroundResource(R.drawable.botaored);
                tv.setText("O ultimo botão salvo em suas Preferências, foi o Botão: "+String.valueOf(getString(R.string.um)));
                break;
            case "2":
                d.setBackgroundResource(R.drawable.botaored);
                tv.setText("O ultimo botão salvo em suas Preferências, foi o Botão: 2");
                break;
            case "3":
                t.setBackgroundResource(R.drawable.botaored);
                tv.setText("O ultimo botão salvo em suas Preferências, foi o Botão: 3");
                break;
            case "4":
                q.setBackgroundResource(R.drawable.botaored);
                tv.setText("O ultimo botão salvo em suas Preferências, foi o Botão: 4");
                break;

        }

        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botaored);

                d.setBackgroundResource(R.drawable.botao);

                t.setBackgroundResource(R.drawable.botao);

                q.setBackgroundResource(R.drawable.botao);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "1");
                editor.apply();
                Toast.makeText(Pref.this, "Estado do botão alterado" +" "+String.valueOf(getString(R.string.save)),
                        Toast.LENGTH_SHORT).show();
                tv.setText("Estado do botão alterado" +" "+String.valueOf(getString(R.string.save))+": 1");

            }
        });


        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botao);

                d.setBackgroundResource(R.drawable.botaored);

                t.setBackgroundResource(R.drawable.botao);

                q.setBackgroundResource(R.drawable.botao);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "2");
                editor.apply();
                Toast.makeText(Pref.this, "Estado do botão alterado" +" "+String.valueOf(getString(R.string.save)),
                        Toast.LENGTH_SHORT).show();
                tv.setText("Estado do botão alterado" +" "+String.valueOf(getString(R.string.save))+": 2");

            }
        });

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botao);

                d.setBackgroundResource(R.drawable.botao);

                t.setBackgroundResource(R.drawable.botaored);

                q.setBackgroundResource(R.drawable.botao);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "3");
                editor.apply();
                Toast.makeText(Pref.this, "Estado do botão alterado" +" "+String.valueOf(getString(R.string.save)),
                        Toast.LENGTH_SHORT).show();
                tv.setText("Estado do botão alterado" +" "+String.valueOf(getString(R.string.save))+": 3");

            }
        });

        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botao);

                d.setBackgroundResource(R.drawable.botao);

                t.setBackgroundResource(R.drawable.botao);

                q.setBackgroundResource(R.drawable.botaored);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "4");
                editor.apply();
                Toast.makeText(Pref.this, "Estado do botão alterado" +" "+String.valueOf(getString(R.string.save)),
                        Toast.LENGTH_SHORT).show();
                tv.setText("Estado do botão alterado" +" "+String.valueOf(getString(R.string.save))+": 4");

            }
        });


      }

    @Override
    public void onBackPressed() {
        finish();
    }
  }

