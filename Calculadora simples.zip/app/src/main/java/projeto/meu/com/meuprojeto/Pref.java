package projeto.meu.com.meuprojeto;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by DEF on 18/10/2016.
 * www.aksr.com.br
 */
public class Pref extends Activity {
    Intent logou;
    protected static TextView sign;
    protected static EditText nome, senha;
    protected static Button logar, criar,def;
    private static final int PERMISSIONS = 102;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pref);

        final Button u = (Button)findViewById(R.id.um);
        final Button d = (Button)findViewById(R.id.dois);
        final Button t = (Button)findViewById(R.id.tres);
        final Button q = (Button)findViewById(R.id.quatro);
        final TextView tv = (TextView)findViewById(R.id.getpref);


        SharedPreferences Botao = getSharedPreferences("Pref", MODE_PRIVATE);
        String botao = Botao.getString("btn", "");
        switch (botao) {
            case "1":
                u.setBackgroundResource(R.drawable.botaored);
                tv.setText(String.valueOf(getString(R.string.b1)) +String.valueOf(getString(R.string.um)));
                break;
            case "2":
                d.setBackgroundResource(R.drawable.botaored);
                tv.setText(String.valueOf(getString(R.string.b1)) +String.valueOf(getString(R.string.dois)));
                break;
            case "3":
                t.setBackgroundResource(R.drawable.botaored);
                tv.setText(String.valueOf(getString(R.string.b1)) +String.valueOf(getString(R.string.tres)));
                break;
            case "4":
                q.setBackgroundResource(R.drawable.botaored);
                tv.setText(String.valueOf(getString(R.string.b1)) +String.valueOf(getString(R.string.quatro)));
                break;

        }

        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botaored);

                d.setBackgroundResource(R.drawable.botao);

                t.setBackgroundResource(R.drawable.botao);

                q.setBackgroundResource(R.drawable.botao);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "1");
                editor.apply();


                tv.setText(String.valueOf(getString(R.string.b1))
                          +String.valueOf(getString(R.string.save))
                          + String.valueOf(getString(R.string.um)));

            }
        });


        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botao);

                d.setBackgroundResource(R.drawable.botaored);

                t.setBackgroundResource(R.drawable.botao);

                q.setBackgroundResource(R.drawable.botao);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "2");
                editor.apply();

                tv.setText(String.valueOf(getString(R.string.b1))
                        +String.valueOf(getString(R.string.save))
                        + String.valueOf(getString(R.string.dois)));

            }
        });

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botao);

                d.setBackgroundResource(R.drawable.botao);

                t.setBackgroundResource(R.drawable.botaored);

                q.setBackgroundResource(R.drawable.botao);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "3");
                editor.apply();

                tv.setText(String.valueOf(getString(R.string.b1))
                        +String.valueOf(getString(R.string.save))
                        + String.valueOf(getString(R.string.tres)));

            }
        });

        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                u.setBackgroundResource(R.drawable.botao);

                d.setBackgroundResource(R.drawable.botao);

                t.setBackgroundResource(R.drawable.botao);

                q.setBackgroundResource(R.drawable.botaored);

                SharedPreferences btum = getSharedPreferences("Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = btum.edit();
                editor.putString("btn", "4");
                editor.apply();

                tv.setText(String.valueOf(getString(R.string.b1))
                        +String.valueOf(getString(R.string.save))
                        + String.valueOf(getString(R.string.quatro)));

            }
        });


      }

    @Override
    public void onBackPressed() {
        finish();
    }
  }

