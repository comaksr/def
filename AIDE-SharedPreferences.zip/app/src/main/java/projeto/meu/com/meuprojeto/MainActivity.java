package projeto.meu.com.meuprojeto;


import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.view.*;
import android.widget.*;
import android.support.v7.widget.Toolbar;



public class MainActivity extends AppCompatActivity {
    String sred = "ToolBar ser tornou: Vermelha";
    String sgreen = "ToolBar ser tornou: Verde";
    String sblue = "ToolBar ser tornou: Azul";
    String sblack = "ToolBar ser tornou: Preta";
    MediaPlayer a,b = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a = MediaPlayer.create(this, R.raw.a);
        b = MediaPlayer.create(this, R.raw.b);
        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SharedPreferences Botao = getSharedPreferences("Dados", MODE_PRIVATE);
        String botao = Botao.getString("botao", "");
        switch (botao) {
            case "vermelho":
                toolbar.setBackgroundResource(R.drawable.botaored);
                break;
            case "verde":
                toolbar.setBackgroundResource(R.drawable.botao2);
                break;
            case "azul":
                toolbar.setBackgroundResource(R.drawable.btn);
                break;
            case "preto":
                toolbar.setBackgroundResource(R.drawable.botaopreto);
                break;
            default:
                //noinspection deprecation
                toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                break;
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                //noinspection deprecation
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_TEXT, "Nome APP..." + "\n" +
                                                  "Descrição" + "\n" + "\n" +
                                                  "http://www.aksr.com.br/" + "\n");
                startActivity(Intent.createChooser(share, "Compartilhar"));


                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        //.setAction("Action", null).show();
            }
        });


        Button padrao = (Button) findViewById(R.id.padrao);
        padrao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                //noinspection deprecation
                toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

                SharedPreferences preto = getSharedPreferences("Dados", MODE_PRIVATE);
                SharedPreferences.Editor editor = preto.edit();
                editor.putString("botao", "");
                editor.apply();
            }
        });


        Button black = (Button) findViewById(R.id.black);
        black.setBackgroundResource(R.drawable.botaopreto);
        black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                toolbar.setBackgroundResource(R.drawable.botaopreto);
                toolbar.setTitle(sblack);

                SharedPreferences preto = getSharedPreferences("Dados", MODE_PRIVATE);
                SharedPreferences.Editor editor = preto.edit();
                editor.putString("botao", "preto");
                editor.apply();
            }
        });

        Button blue = (Button) findViewById(R.id.blue);
        blue.setBackgroundResource(R.drawable.btn);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                toolbar.setBackgroundResource(R.drawable.btn);
                toolbar.setTitle(sblue);

                SharedPreferences azul = getSharedPreferences("Dados", MODE_PRIVATE);
                SharedPreferences.Editor editor = azul.edit();
                editor.putString("botao", "azul");
                editor.apply();

            }
        });

		 Button green= (Button) findViewById(R.id.green);
        green.setBackgroundResource(R.drawable.botao2);
        green.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
                    a.start();
					Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
					toolbar.setBackgroundResource(R.drawable.botao2);
                    toolbar.setTitle(sgreen);

                    SharedPreferences verde = getSharedPreferences("Dados", MODE_PRIVATE);
                    SharedPreferences.Editor editor = verde.edit();
                    editor.putString("botao", "verde");
                    editor.apply();

				}
			});



        Button red = (Button) findViewById(R.id.red);
        red.setBackgroundResource(R.drawable.botaored);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.start();
                toolbar.setBackgroundResource(R.drawable.botaored);
                toolbar.setTitle(sred);

                SharedPreferences vermelho = getSharedPreferences("Dados", MODE_PRIVATE);
                SharedPreferences.Editor editor = vermelho.edit();
                editor.putString("botao", "vermelho");
                editor.apply();

            }
        });







    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SubMenu subMenu = menu.addSubMenu(Menu.NONE, 0, 0, "");
        subMenu.getItem().setIcon(R.drawable.m);
        subMenu.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        subMenu.add(0, 1, 0, R.string.action_settings).setIcon(R.drawable.eng);
       // subMenu.add(0, 2, 0, R.string.app_name).setIcon(R.drawable.ic_launcher);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        b.start();
        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.parse("package:" + getPackageName());
                intent.setData(uri);
                startActivity(intent);
                return true;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
        System.exit(0);
    }


}


