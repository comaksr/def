package projeto.meu.com.meuprojeto;

import android.app.Application;

/**
 * Created by Allan Ribas on 28/11/2016.
 */
public class Aplication extends Application {
}
