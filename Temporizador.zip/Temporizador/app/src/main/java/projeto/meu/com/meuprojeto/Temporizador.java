package projeto.meu.com.meuprojeto;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.concurrent.TimeUnit;

/**
 * Created by Allan Ribas on 21/12/2016.
 */
public class Temporizador extends Activity {
    EditText numero;
    Button botaocontagem,cronometro,sairdoapp;
    TextView getime;
    protected static final String FORMAT = "%02d:%02d:%02d";
    Uri alarmSound;
    public static MediaPlayer time = new MediaPlayer();
    Handler mHandler = new Handler();
    int seconds,minutes,hours = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temporizador);

        Intent returnBtn = new Intent(getApplicationContext(), Temporizador.class);
        startActivity(returnBtn);

        numero = (EditText)findViewById(R.id.numero);

        botaocontagem = (Button)findViewById(R.id.botaocontagem);
        cronometro = (Button)findViewById(R.id.cronometro);
        getime = (TextView)findViewById(R.id.getime);
        sairdoapp = (Button)findViewById(R.id.sairdoapp);
        final AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        final int maxVolume = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        time = MediaPlayer.create(Temporizador.this, R.raw.intro);




        botaocontagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (numero.length() <=0) {
                    new AlertDialog.Builder(Temporizador.this)
                            .setTitle("Valor inválido!")
                            .setMessage("Digite um valor....")
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            })
                            .setIcon(R.drawable.ic_launcher)
                            .show();
                }else{
                    botaocontagem.setVisibility(View.GONE);
                    numero.setVisibility(View.GONE);
                    cronometro.setVisibility(View.GONE);
                    getime.setVisibility(View.VISIBLE);
                    int v2 = Integer.parseInt(numero.getText().toString())*1000;
                    CountDownTimer countDownTimer = new CountDownTimer(v2, 1000) {
                        public void onTick(long millisUntilFinished) {
                            getime.setText("" + String.format(FORMAT,
                                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                                            TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));

                }
                        public void onFinish() {
                        float percent = 1.0f;
                        int seventyVolume = (int) (maxVolume * percent);
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, seventyVolume, 10);
                        time.start();
                        getime.setText("Tempo esgotado");
                        mHandler.postDelayed(new Runnable() {
                            public void run() {
                                botaocontagem.setVisibility(View.VISIBLE);
                                numero.setVisibility(View.VISIBLE);
                                cronometro.setVisibility(View.VISIBLE);
                                getime.setVisibility(View.GONE);
                            }
                        }, 19000);

                    }
                }.start();
                countDownTimer.start();
            }  }
        });

        cronometro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pi();
                botaocontagem.setVisibility(View.GONE);
                numero.setVisibility(View.GONE);
                cronometro.setVisibility(View.GONE);
                getime.setVisibility(View.VISIBLE);
            }
                private void pi () {
                    getime.setText(String.valueOf(seconds) + " segundo");
                    if (seconds > 1) {
                        getime.setText(String.valueOf(seconds) + " segundos");
                    }
                    if (minutes == 1) {
                        getime.setText(String.valueOf(minutes) + " minuto " +
                                       String.valueOf(seconds) + " segundos");
                    }
                    if (minutes > 1) {
                        getime.setText(String.valueOf(minutes) + " minutos " +
                                String.valueOf(seconds) + " segundos");
                    }
                    if (hours == 1) {
                        getime.setText(
                                String.valueOf(hours) + " hora " +
                                String.valueOf(minutes) + " minutos " +
                                String.valueOf(seconds) + " segundos");
                    }
                    if (hours > 1) {
                        getime.setText(
                                String.valueOf(hours) + " horas " +
                                        String.valueOf(minutes) + " minutos " +
                                        String.valueOf(seconds) + " segundos");
                    }


                    if (seconds >= 59) {
                        seconds = 0;
                        minutes++;
                    }
                    if (minutes >= 59) {
                        minutes = 0;
                        hours++;
                    }
                    tempando();
                }

            private void tempando() {
                mHandler.postDelayed(new Runnable() {
                    public void run() {
                        pi();
                        seconds++;
                    }
                }, 1000);
            }
        });


        sairdoapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                System.exit(0);
            }
        });

    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

}
