package projeto.meu.com.meuprojeto;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Allan Ribas on 18/12/2016.
 */
public class NotificationBuilder extends Activity {
    Button TurnOn, TurnOff;
    EditText titulo,mensagem;
    NotificationManager notifManager;
    NotificationCompat.Builder noti;
    Uri alarmSound;
    Handler mHandler = new Handler();
    CheckBox sompadrao,somA,somB;
    ProgressDialog mProgress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_builder);


        somA = (CheckBox)findViewById(R.id.somA);
        somB = (CheckBox)findViewById(R.id.somB);
        sompadrao = (CheckBox)findViewById(R.id.sompadrao);




        sompadrao.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (sompadrao.isChecked()) {
                    somA.setChecked(false);
                    somB.setChecked(false);
                    alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                }
            }
        });
        somA.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (somA.isChecked()) {
                    sompadrao.setChecked(false);
                    somB.setChecked(false);
                    alarmSound = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.intro);

                }
            }
        });
        somB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (somB.isChecked()) {
                    sompadrao.setChecked(false);
                    somA.setChecked(false);
                    alarmSound = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.b);
                }
            }
        });







        titulo = (EditText) findViewById(R.id.titulo);
        titulo.setHint(String.valueOf(getString(R.string.titulo)));
        titulo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(TextUtils.isEmpty(s)){
                    TurnOn.setVisibility(View.GONE);}
                else{TurnOn.setVisibility(View.VISIBLE);}}
            @Override
            public void afterTextChanged(Editable s) {}
        });


        mensagem = (EditText) findViewById(R.id.mensagem);
        mensagem.setHint(String.valueOf(getString(R.string.mensagem)));
        mensagem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(TextUtils.isEmpty(s)){
                    TurnOn.setVisibility(View.GONE);}
                else{TurnOn.setVisibility(View.VISIBLE);}}
            @Override
            public void afterTextChanged(Editable s) {}
        });



        TurnOn = (Button) findViewById(R.id.TurnOn);
        TurnOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noti = new NotificationCompat.Builder(NotificationBuilder.this);
                noti.setContentTitle(titulo.getText().toString());
                noti.setContentText(mensagem.getText().toString());
                noti.setSmallIcon(android.R.drawable.ic_lock_idle_alarm);
                noti.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher));
                noti.setSound(alarmSound);
                noti.setOngoing(true);
                noti.build();
                notificacao();
                mProgress = new ProgressDialog(NotificationBuilder.this);
                mProgress.setIcon(R.drawable.blogspot);
                mProgress.setMessage("Aguarde...\n" +
                        "3...2..1.");
                mProgress.show();
                mProgress.setCancelable(false);
            }
        });

        TurnOff = (Button) findViewById(R.id.TurnOff);
        TurnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notifManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notifManager.cancelAll();
                Toast.makeText(NotificationBuilder.this, "Notificação dispensada", Toast.LENGTH_SHORT).show();
                TurnOn.setVisibility(View.VISIBLE);
                TurnOff.setVisibility(View.GONE);
            }
        });
    }

    void notificacao(){
        mHandler.postDelayed(new Runnable() {
            public void run() {
                notifManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                notifManager.notify(0, noti.build());
                Toast.makeText(NotificationBuilder.this, "Notificado", Toast.LENGTH_SHORT).show();
                TurnOff.setVisibility(View.VISIBLE);
                TurnOn.setVisibility(View.GONE);
                mProgress.dismiss();
            }
        }, 3000);

    }


}