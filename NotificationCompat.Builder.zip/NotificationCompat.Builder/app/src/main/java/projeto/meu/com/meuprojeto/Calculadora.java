package projeto.meu.com.meuprojeto;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Calculadora extends AppCompatActivity {
    protected static Dialog customDialog;
    public static MediaPlayer a,b = new MediaPlayer();
    public static Button somar,subtrair,multiplicar,dividir,porcentagem,clear;
    public static Toolbar toolbar;
    public static FloatingActionButton fab;
    protected static TextView cs,result;
    protected static EditText n1,n2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        a = MediaPlayer.create(this, R.raw.a);
        b = MediaPlayer.create(this, R.raw.b);

        cs = (TextView) findViewById(R.id.cs);
        cs.setText("Calculo Simples");
        cs.setTextColor(Color.BLACK);

        n1 = (EditText) findViewById(R.id.n1);
        n1.setHint("Digite um valor");
        n1.setHintTextColor(Color.BLACK);
        n1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() < 1){
                    clear.setVisibility(View.GONE);}
                else{clear.setVisibility(View.VISIBLE);}}
            @Override
            public void afterTextChanged(Editable s) {}
        });

        n2 = (EditText) findViewById(R.id.n2);
        n2.setHint("Digite um valor");
        n2.setHintTextColor(Color.BLACK);
        n2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() < 1){
                    clear.setVisibility(View.GONE);
                    }
                else{clear.setVisibility(View.VISIBLE);}}
            @Override
            public void afterTextChanged(Editable s) {}
        });


        result = (TextView) findViewById(R.id.result);
        result.setText("");
        result.setTextColor(Color.BLACK);

        somar = (Button) findViewById(R.id.somar);
        somar.setText("+");
        somar.setTextColor(Color.BLACK);
        somar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                if(n1.length() < 1 || n2.length() < 1){
                    Snackbar.make(view, "Os campos não podem estar vazios", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
                }else{
                    float v1 = Float.parseFloat(n1.getText().toString());
                    float v2 = Float.parseFloat(n2.getText().toString());
                    float Resultado = v1+v2;
                    String RE = String.valueOf(Resultado);
                    result.setText(RE);
                    result.setVisibility(View.VISIBLE);
                }
            }
        });

        subtrair = (Button) findViewById(R.id.subtrair);
        subtrair.setText("-");
        subtrair.setTextColor(Color.BLACK);
        subtrair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                if(n1.length() < 1 || n2.length() < 1){
                    Snackbar.make(view, "Os campos não podem estar vazios", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }else{
                    float v1 = Float.parseFloat(n1.getText().toString());
                    float v2 = Float.parseFloat(n2.getText().toString());
                    float Resultado = v1-v2;
                    String RE = String.valueOf(Resultado);
                    result.setText(RE);
                    result.setVisibility(View.VISIBLE);
                }
            }
        });

        multiplicar = (Button) findViewById(R.id.multiplicar);
        multiplicar.setText("x");
        multiplicar.setTextColor(Color.BLACK);
        multiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                if(n1.length() < 1 || n2.length() < 1){
                    Snackbar.make(view, "Os campos não podem estar vazios", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }else{
                    float v1 = Float.parseFloat(n1.getText().toString());
                    float v2 = Float.parseFloat(n2.getText().toString());
                    float Resultado = v1*v2;
                    String RE = String.valueOf(Resultado);
                    result.setText(RE);
                    result.setVisibility(View.VISIBLE);
                }
            }
        });

        dividir = (Button) findViewById(R.id.dividir);
        dividir.setText("÷");
        dividir.setTextColor(Color.BLACK);
        dividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                if(n1.length() < 1 || n2.length() < 1){
                    Snackbar.make(view, "Os campos não podem estar vazios", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }else{
                    float v1 = Float.parseFloat(n1.getText().toString());
                    float v2 = Float.parseFloat(n2.getText().toString());
                    float Resultado = v1/v2;
                    String RE = String.valueOf(Resultado);
                    result.setText(RE);
                    result.setVisibility(View.VISIBLE);
                }
            }
        });

        porcentagem = (Button) findViewById(R.id.porcentagem);
        porcentagem.setText("%");
        porcentagem.setTextColor(Color.BLACK);
        porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                if(n1.length() < 1 || n2.length() < 1){
                    Snackbar.make(view, "Os campos não podem estar vazios", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }else{
                    float v1 = Float.parseFloat(n1.getText().toString());
                    float v2 = Float.parseFloat(n2.getText().toString());
                    float Resultado = v1*v2;
                    float POR = Resultado/100;
                    String RE = String.valueOf(POR);
                    result.setText(RE);
                    result.setVisibility(View.VISIBLE);
                }
            }
        });


        clear = (Button) findViewById(R.id.clear);
        clear.setTextColor(Color.BLACK);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Snackbar.make(view, "Os campos não podem estar vazios", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                n1.setText("");
                n2.setText("");
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
                result.setVisibility(View.GONE);

            }
        });


        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                //noinspection deprecation
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_TEXT, String.valueOf(getString(R.string.app_name))
                        + "\n" +
                        String.valueOf(getString(R.string.descricao)) + "\n" + "\n" +
                        String.valueOf(getString(R.string.site)) + "\n");
                startActivity(Intent.createChooser(share, String.valueOf(getString(R.string.compartilhar))));


                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //.setAction("Action", null).show();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SubMenu subMenu = menu.addSubMenu(Menu.NONE, 0, 0, "");
        subMenu.getItem().setIcon(R.drawable.m);
        subMenu.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        subMenu.add(0, 1, 0, R.string.action_settings).setIcon(R.drawable.eng);
        subMenu.add(0, 2, 0, R.string.deslogar).setIcon(R.drawable.deslogar);
       // subMenu.add(0, 3, 0, R.string.pref).setIcon(R.drawable.ic_launcher);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        b.start();
        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.parse("package:" + getPackageName());
                intent.setData(uri);
                startActivity(intent);
                return true;

            case 2:

                        finish();


                return true;
        }

        return super.onOptionsItemSelected(item);
    }




}