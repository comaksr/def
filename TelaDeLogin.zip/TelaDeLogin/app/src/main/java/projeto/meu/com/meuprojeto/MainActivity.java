package projeto.meu.com.meuprojeto;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.*;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.*;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.support.v7.widget.Toolbar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    protected static Dialog customDialog;
    public static String sred = "ToolBar ser tornou: Vermelha";
    public static String sgreen = "ToolBar ser tornou: Verde";
    public static String sblue = "ToolBar ser tornou: Azul";
    public static String sblack = "ToolBar ser tornou: Preta";
    public static MediaPlayer a, b,c = new MediaPlayer();
    private static final int PERMISSIONS = 102;
    public static Button check,run,black,blue,green,red,padrao,play,stop,zerar,tube;
    public static Toolbar toolbar;
    public static FloatingActionButton fab;
    protected static TextView c1,c2,c3,c4,c5,c6;
    public static VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        videoView = new VideoView(this);
        a = MediaPlayer.create(this, R.raw.a);
        b = MediaPlayer.create(this, R.raw.b);
        check = (Button) findViewById(R.id.check);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        memoria();
        /*
        SharedPreferences Botao = getSharedPreferences("Dados", MODE_PRIVATE);
        String botao = Botao.getString("botao", "");
        switch (botao) {
            case "vermelho":
                toolbar.setBackgroundResource(R.drawable.botaored);
                break;
            case "verde":
                toolbar.setBackgroundResource(R.drawable.botao2);
                break;
            case "azul":
                toolbar.setBackgroundResource(R.drawable.btn);
                break;
            case "preto":
                toolbar.setBackgroundResource(R.drawable.botaopreto);
                break;
            default:
                //noinspection deprecation
                toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                break;
        }
         */

        //if (Build.VERSION.SDK_INT < 23) {}


        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                //noinspection deprecation
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_TEXT, "Nome APP..." + "\n" +
                        "Descrição" + "\n" + "\n" +
                        "http://www.aksr.com.br/" + "\n");
                startActivity(Intent.createChooser(share, "Compartilhar"));


                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //.setAction("Action", null).show();
            }
        });
        run = (Button) findViewById(R.id.run);
        run.setVisibility(View.GONE);
        run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                checkAndRequestPermissions();
            }
        });

        //Build.VERSION_CODES.M
        if (Build.VERSION.SDK_INT < 23) {run.setVisibility(View.VISIBLE);}else {
            int MEM = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (MEM == PackageManager.PERMISSION_DENIED) {
                run.setVisibility(View.VISIBLE);
            }
        }


        final String path = String.valueOf(R.raw.intro);
        final EditText songpath = (EditText)findViewById(R.id.songpath);
        songpath.setText(path);
        zerar = (Button) findViewById(R.id.zerar);
        zerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                songpath.setText(path);

            }
        });
        tube = (Button) findViewById(R.id.tube);
        tube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                songpath.setText("https://www.youtube.com/watch?v=RpE_VJ_rBek");

            }
        });

        play = (Button) findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(songpath.getText().toString().contains(".youtube")){
                    videoView.setVideoURI(Uri.parse(String.valueOf(songpath.getText())));
                    startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(String.valueOf(songpath.getText()))));
                }else {
                    videoView.setMediaController(new MediaController(MainActivity.this));
                    videoView = (VideoView) findViewById(R.id.video);
                    videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + songpath.getText()));
                    videoView.setBackgroundResource(0);
                    videoView.start();
                }


            }
        });
        stop = (Button) findViewById(R.id.stop);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoView.stopPlayback();

            }
        });





        padrao = (Button) findViewById(R.id.padrao);
        padrao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                //noinspection deprecation
                toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

                //SharedPreferences preto = getSharedPreferences("Dados", MODE_PRIVATE);
                //SharedPreferences.Editor editor = preto.edit();
                // editor.putString("botao", "");
                //editor.apply();


                defeaut();
            }
        });


        black = (Button) findViewById(R.id.black);
        black.setBackgroundResource(R.drawable.botaopreto);
        black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                toolbar.setBackgroundResource(R.drawable.botaopreto);
                toolbar.setTitle(sblack);

                //SharedPreferences preto = getSharedPreferences("Dados", MODE_PRIVATE);
                //SharedPreferences.Editor editor = preto.edit();
                // editor.putString("botao", "preto");
                // editor.apply();


                black();
            }
        });

        blue = (Button) findViewById(R.id.blue);
        blue.setBackgroundResource(R.drawable.btn);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                toolbar.setBackgroundResource(R.drawable.btn);
                toolbar.setTitle(sblue);

                //SharedPreferences azul = getSharedPreferences("Dados", MODE_PRIVATE);
                //SharedPreferences.Editor editor = azul.edit();
                // editor.putString("botao", "azul");
                // editor.apply();


                blue();

            }
        });

        green = (Button) findViewById(R.id.green);
        green.setBackgroundResource(R.drawable.botao2);
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a.start();
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                toolbar.setBackgroundResource(R.drawable.botao2);
                toolbar.setTitle(sgreen);

                //SharedPreferences verde = getSharedPreferences("Dados", MODE_PRIVATE);
                //SharedPreferences.Editor editor = verde.edit();
                //editor.putString("botao", "verde");
                //editor.apply();


                green();

            }
        });


        red = (Button) findViewById(R.id.red);
        red.setBackgroundResource(R.drawable.botaored);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.start();
                toolbar.setBackgroundResource(R.drawable.botaored);
                toolbar.setTitle(sred);

                //SharedPreferences vermelho = getSharedPreferences("Dados", MODE_PRIVATE);
                //SharedPreferences.Editor editor = vermelho.edit();
                //editor.putString("botao", "vermelho");
                //editor.apply();


                red();
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        SubMenu subMenu = menu.addSubMenu(Menu.NONE, 0, 0, "");
        subMenu.getItem().setIcon(R.drawable.m);
        subMenu.getItem().setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        subMenu.add(0, 1, 0, R.string.action_settings).setIcon(R.drawable.eng);
        subMenu.add(0, 2, 0, R.string.deslogar).setIcon(R.drawable.deslogar);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        b.start();
        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.parse("package:" + getPackageName());
                intent.setData(uri);
                startActivity(intent);
                return true;

            case 2:
                try {
                    //File folder = this.getDir("PROJETO", Context.MODE_PRIVATE);
                    File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
                    File tempp = new File(folder, ".logtemp.txt");
                    try {
                        FileOutputStream out = new FileOutputStream(tempp);

                        String content = "";

                        byte[] contentInBytes = content.getBytes();

                        out.write(contentInBytes);
                        out.flush();
                        out.close();
                        finish();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } catch (Exception ignored) {}
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        customDialog = new Dialog(MainActivity.this, R.style.Theme_Dialog_Translucent);
        customDialog.getWindow().getAttributes().windowAnimations = R.style.Dialogenter;
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.choices);
        customDialog.setCancelable(true);




        c1 = (TextView) customDialog.findViewById(R.id.c1);
        c1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Opção 1  ", Toast.LENGTH_LONG).show();

            }
        });

        c2 = (TextView) customDialog.findViewById(R.id.c2);
        c2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Opção 2  ", Toast.LENGTH_LONG).show();
            }
        });

        c3 = (TextView) customDialog.findViewById(R.id.c3);
        c3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Opção 3  ", Toast.LENGTH_LONG).show();
            }
        });
        c4 = (TextView) customDialog.findViewById(R.id.c4);
        c4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Sair");
                dialog.setMessage("Deseja sair?");
                dialog.setCancelable(true);
                dialog.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        System.exit(0);
                    }
                });
                dialog.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                dialog.setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

            }
        });
        c5 = (TextView) customDialog.findViewById(R.id.c5);
        c5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });
        c6 = (TextView) customDialog.findViewById(R.id.c6);
        c6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                customDialog.dismiss();
            }
        });

        customDialog.show();
    }





        /*
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Sair");
        dialog.setMessage("Deseja sair?");
        dialog.setCancelable(true);
        dialog.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        System.exit(0);
                    }
                });
        dialog.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog.setIcon(android.R.drawable.ic_dialog_alert)
                .show();
*/
    //finish();
    //System.exit(0);



    void red() {
        File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
        File fileWithinMyDir = new File(folder, "Dados.txt");
        try {
            FileOutputStream out = new FileOutputStream(fileWithinMyDir); //Use the stream as usual to write into the file.

            String content = "vermelho";

            byte[] contentInBytes = content.getBytes();

            out.write(contentInBytes);
            out.flush();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdir();

        }

    }

    void green() {
        File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
        File fileWithinMyDir = new File(folder, "Dados.txt");
        try {
            FileOutputStream out = new FileOutputStream(fileWithinMyDir); //Use the stream as usual to write into the file.

            String content = "verde";

            byte[] contentInBytes = content.getBytes();

            out.write(contentInBytes);
            out.flush();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdir();

        }

    }

    void black() {
        File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
        File fileWithinMyDir = new File(folder, "Dados.txt");
        try {
            FileOutputStream out = new FileOutputStream(fileWithinMyDir); //Use the stream as usual to write into the file.

            String content = "preto";

            byte[] contentInBytes = content.getBytes();

            out.write(contentInBytes);
            out.flush();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdir();
        }

    }


    void blue() {
        File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
        File fileWithinMyDir = new File(folder, "Dados.txt");
        try {
            FileOutputStream out = new FileOutputStream(fileWithinMyDir); //Use the stream as usual to write into the file.

            String content = "azul";

            byte[] contentInBytes = content.getBytes();

            out.write(contentInBytes);
            out.flush();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdir();

        }


    }


    void defeaut() {
        File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
        File fileWithinMyDir = new File(folder, "Dados.txt");
        try {
            FileOutputStream out = new FileOutputStream(fileWithinMyDir); //Use the stream as usual to write into the file.

            String content = "";

            byte[] contentInBytes = content.getBytes();

            out.write(contentInBytes);
            out.flush();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!folder.exists()) {
            //noinspection ResultOfMethodCallIgnored
            folder.mkdir();
            //noinspection ResultOfMethodCallIgnored
        }

    }


    @TargetApi(Build.VERSION_CODES.M)
    private boolean checkAndRequestPermissions() {
        int LER = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int ESCREVER = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        List<String> listPermissionsNeeded = new ArrayList<>();

        if (LER != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (ESCREVER != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),
                    PERMISSIONS);
            return false;
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS) {
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++) {

                    if (permissions[i].equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(MainActivity.this, "Acesso: concedido" + "[ Agora você pode LER seus arquivos ]", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                    } else if (permissions[i].equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(MainActivity.this, "Acesso: concedido" + "[ Agora você pode ESCREVER em seus arquivos ]", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                }

            }
        }
    }





    void memoria(){
        try {
            check = (Button) findViewById(R.id.check);
            toolbar = (Toolbar) findViewById(R.id.toolbar);

            File folder = new File(Environment.getExternalStorageDirectory() + "/PROJETO");
            File fileWithinMyDir = new File(folder, "Dados.txt");

            FileInputStream fIn = new FileInputStream(fileWithinMyDir);
            BufferedReader myReader = new BufferedReader(
                    new InputStreamReader(fIn));
            String aDataRow = "";
            String aBuffer = "";
            while ((aDataRow = myReader.readLine()) != null) {
                aBuffer += aDataRow;
            }

            check.setText(aBuffer);
            myReader.close();
            Toast.makeText(getBaseContext(), aBuffer,
                    Toast.LENGTH_LONG).show();
            switch (aBuffer) {
                case "vermelho":
                    toolbar.setBackgroundResource(R.drawable.botaored);
                    break;
                case "verde":
                    toolbar.setBackgroundResource(R.drawable.botao2);
                    break;
                case "azul":
                    toolbar.setBackgroundResource(R.drawable.btn);
                    break;
                case "preto":
                    toolbar.setBackgroundResource(R.drawable.botaopreto);
                    break;
                case "fechar":
                    Toast.makeText(MainActivity.this, "Aplicação em Manutenção", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    //noinspection deprecation
                    toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    break;
            }


        } catch (Exception e) {
            check = (Button) findViewById(R.id.check);
            check.setText("Permissão Negada");
        }
    }


}